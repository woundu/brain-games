import random, prompt
from brain_games.cli import generate_num



def check(num,answer):
    even = num % 2 ==0 
    odd = num % 2 !=0
    if answer=="yes" and even or answer=="no" and odd:
        result = True
    return result

        
def check_answer():
    attempts = 3
    while attempts!=0:
        num =  generate_num()
        print (f"Question: {num}?")
        answer = prompt.string("Your answer:")
        result =  check(num,answer)
        if result:
            print ("Congratulations!")
            attempts-=1
        else:
            print ("You loose!")
            break

      
def main():

    print ("Answer \'yes\' if the number is even, otherwise answer \'no\'.")
    check_answer()


    
    
